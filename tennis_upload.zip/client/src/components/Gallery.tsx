import { useState } from 'react';
import { X } from 'lucide-react';

interface GalleryImage {
  src: string;
  alt: string;
  description: string;
}

const Gallery = () => {
  const [selectedImage, setSelectedImage] = useState<GalleryImage | null>(null);

  const images: GalleryImage[] = [
    {
      src: '/gallery/aea2f9fe-4433-4df0-a946-ee9bddaf6b41.jpg',
      alt: 'Entraînement sur court extérieur',
      description: 'Session d\'entraînement avec mes élèves sur court extérieur'
    },
    {
      src: '/gallery/e1c1d9ab-8d61-4883-8214-c430b0bafbcf.jpg',
      alt: 'Champion avec trophée',
      description: 'Célébration de victoire avec un de mes élèves'
    },
    {
      src: '/gallery/0a7f6124-43bd-4d87-b804-6e84e9b1412d.jpg',
      alt: 'Match final au Tennis Club de Tunis',
      description: 'Finale au Tennis Club de Tunis'
    },
    {
      src: '/gallery/8b001041-a0f7-4676-a76b-0beecb6f6f80.jpg',
      alt: 'Rogers Cup à Montréal',
      description: 'Au Rogers Cup à Montréal - Expérience internationale'
    },
    {
      src: '/gallery/9f4b4a6d-d7f3-477a-95f0-d572152292cb.jpg',
      alt: 'Tennis Club de Sousse',
      description: 'Avec mes champions au Tennis Club de Sousse'
    },
    {
      src: '/gallery/6dbf86d2-64ea-4913-a102-87f19a32c1dd.jpg',
      alt: 'Groupe d\'enfants en entraînement',
      description: 'Session de groupe avec jeunes joueurs'
    },
    {
      src: '/gallery/562e45bd-48d8-4651-a1b8-0badc0f6395d.jpg',
      alt: 'Coaching individuel',
      description: 'Cours privé avec une jeune joueuse'
    }
  ];

  return (
    <section className="section-dark px-6 py-20">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-4xl md:text-5xl font-medium mb-4 text-white">
          Galerie Photos
        </h2>
        <p className="text-lg md:text-xl mb-12 text-white/80 max-w-3xl">
          Découvrez mes sessions d'entraînement, mes élèves champions et les moments forts de ma carrière de coach.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {images.map((image, index) => (
            <div
              key={index}
              className="group relative overflow-hidden rounded-2xl cursor-pointer aspect-[4/3] bg-gray-800"
              onClick={() => setSelectedImage(image)}
            >
              <img
                src={image.src}
                alt={image.alt}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <p className="text-white font-medium text-lg">{image.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Modal pour afficher l'image en grand */}
      {selectedImage && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 p-4"
          onClick={() => setSelectedImage(null)}
        >
          <button
            className="absolute top-4 right-4 text-white hover:text-gray-300 transition-colors p-2"
            onClick={() => setSelectedImage(null)}
            aria-label="Fermer"
          >
            <X size={32} />
          </button>
          <div className="max-w-6xl w-full">
            <img
              src={selectedImage.src}
              alt={selectedImage.alt}
              className="w-full h-auto max-h-[85vh] object-contain rounded-lg"
            />
            <p className="text-white text-center mt-4 text-lg">
              {selectedImage.description}
            </p>
          </div>
        </div>
      )}
    </section>
  );
};

export default Gallery;
